

<?php $__env->startSection('content'); ?>

<div class="highlight-blue" style="margin: 0px 0px 10px 0px;">
    <div class="container">
        <div class="intro">
            <h2 class="text-center">SLTUTOR</h2>
            <p class="text-center"><br><br>It is important to know that when you tutor a child, you are preparing him or her for the life ahead of them. Everything you teach them is critical to the person they become.<br><br></p>
        </div>
        <div class="buttons"><a class="btn btn-info active" role="button" href="https://www.facebook.com/SLtutorcom-424551631428759" target="_blank"><i class="fa fa-facebook-square" style="font-size: 16px;"></i>&nbsp;Connect with facebook</a></div>
    </div>
</div>
<hr class="d-xl-flex align-self-center mx-auto" style="height: 1px;background-color: #4a4747;width: 75%;">

<a class="btn btn-default d-flex d-xl-flex justify-content-center justify-content-xl-center" href="/posts" style="margin:5px; padding: 10px; border:none; ouline:none;">Go Back</a>

<section>
    <div class="row justify-content-center">

        <div class="col-sm-12 col-md-4 text-center d-flex d-md-flex justify-content-center justify-content-md-center align-items-md-center">
            
            <img class="img-fluid d-flex d-md-flex pulse animated" src="/storage/cover_images/<?php echo e($post->cover_image); ?>" >
        
        </div>
        
        <div class="col-md-6">
            <div class="card border-white">
                <div class="card-body">
                <p class="card-text" style="font-family: ABeeZee, sans-serif;color: rgb(136,137,137);margin: 5px 0px;"><?php echo e($post->created_at); ?><br></p>
                    <h4 class="card-title" style="color: rgb(39,39,39);padding: 0px;"><?php echo e($post->subject); ?></h4>
                    <h4 class="card-title" style="color: rgb(39,39,39);padding: 0px;"><?php echo e($post->fullName); ?><br></h4>
                    <h6 class="text-muted card-subtitle mb-2" style="font-family: ABeeZee, sans-serif;">Sinhala Medium,English Medium<br></h6>
                    <p class="card-text" style="font-family: ABeeZee, sans-serif;color: rgb(136,137,137);margin: 5px 0px;">Private(Individual) Class,Group Class<br></p>
                    <p class="card-text" style="font-family: ABeeZee, sans-serif;color: rgb(136,137,137);margin: 5px 0px;">District -&gt;&nbsp;<?php echo e($post->district); ?><br></p>
                <p class="card-text" style="font-family: Aclonica, sans-serif;color: rgb(49,50,50);font-size: 20px;margin: 5px 0px;">Rs.<?php echo e($post->price); ?><br></p>
                <p class="card-text" style="font-family: ABeeZee, sans-serif;color: rgb(136,137,137);margin: 5px 0px;"><br><?php echo e($post->description); ?><br><br></p>

                <!--**********************************-->

                <p class="card-text" style="font-family: ABeeZee, sans-serif;color: rgb(50,54,54);margin: 5px 0px;">Qualifications : <?php echo e($post->Qualification); ?><br></p>
                <p class="card-text" style="font-family: ABeeZee, sans-serif;color: rgb(50,54,54);margin: 5px 0px;">Occupation : <?php echo e($post->Occupation); ?><br></p>
                <p class="card-text" style="font-family: ABeeZee, sans-serif;color: rgb(50,54,54);margin: 5px 0px;">Age : <?php echo e($post->age); ?><br></p>
                <p class="card-text" style="font-family: ABeeZee, sans-serif;color: rgb(50,54,54);margin: 5px 0px;">Contact : <?php echo e($post->mobile); ?><br></p>
                <p class="card-text" style="font-family: ABeeZee, sans-serif;color: rgb(50,54,54);margin: 5px 0px;">Email : <?php echo e($post->email); ?><br></p>

                <?php if(!Auth::guest()): ?>

                <?php if(Auth::user()->id == $post->user_id): ?>
                <div class="btn-group" role="group">
                <a href="/posts/<?php echo e($post->id); ?>/edit" style="margin: 5px"><button class="btn btn-info" type="button">Edit</button></a>
                
                <?php echo Form::open(['action' => ['PostsController@destroy',$post->id], 'method' => 'POST' ]); ?>


                <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                <?php echo e(Form::submit('Remove',['class' => 'btn btn-danger','style' => 'margin:5px'])); ?>

            
                <?php echo Form::close(); ?>

                </div>

                <?php endif; ?>

                <?php endif; ?>


                </div>
            </div>
        </div>
    </div>
</section>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sltutorLaravel\resources\views/posts/show.blade.php ENDPATH**/ ?>