<?php $__env->startSection('content'); ?>

<div>
<div class="container">
<div class="row">
    <div class="col-md-2 d-xl-flex align-items-xl-start">
        <section>
            <div class="row">
                <div class="col-md-12 justify-content-between align-items-center align-self-center"><img class="rounded-circle img-fluid border d-flex mx-auto" data-bs-hover-animate="pulse" src="/storage/cover_images/noimage.jpg" width="200px" height="200px"></div>
                <div class="col-md-12">
                    <div class="card border-white">
                        <div class="card-body">
                            <h6 class="text-center card-title"><?php echo e(Auth::user()->name); ?></h6>
                            <h6 class="text-center text-muted card-subtitle mb-2" style="font-size: 12px;"><?php echo e(Auth::user()->email); ?></h6>
                            <p class="card-text"></p>

                            <center>
                            <?php echo Form::open([ 'method' => 'POST' ]); ?>


                            <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                            <?php echo e(Form::submit('Edit',['class' => 'btn btn-danger btn-sm'])); ?>


                            <?php echo Form::close(); ?>

                            </center>

                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
    <div class="col-md-8">
        <section>
            <div class="row justify-content-center" style="background-color: #ffffff;">
                <div class="col-md-11" style="margin: 10px 0px 5px 0px;background-color: #ffffff;">
                   
    

                  
                        <div class="row justify-content-center">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">Dashboard</div>
                    
                                    <div class="card-body justify-content-center">
                                        <?php if(session('status')): ?>
                                            <div class="alert alert-success" role="alert">
                                                <?php echo e(session('status')); ?>

                                            </div>
                                        <?php endif; ?>
                                        You are logged in!<br>

                                        <?php if(count($data['posts']) > 0): ?>
                                        <ul>
                                        <?php $__currentLoopData = $data['posts']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $posts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($posts->fullName); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                        <?php endif; ?>

                                        <a href="/posts/create" class="btn btn-success">Create a Post</a>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                   


                </div>


                <!--****************************************************
                            User Posts
                ******************************************************-->
            <?php if(count($data['userPosts']) > 0): ?>
                <?php $__currentLoopData = $data['userPosts']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="col-md-12" data-aos="slide-up" style="margin: 10px 0 px;">
                    <div class="border rounded-0 border-info shadow" style="background-color: #ffffff;padding: 10px; margin: 10px;">
                        <div class="row">

                            

                            <div class="col-md-4 d-xl-flex flex-fill align-self-center justify-content-xl-center align-items-xl-center">
                            <img class="img-fluid" data-bs-hover-animate="pulse" src="/storage/cover_images/<?php echo e($post->cover_image); ?>">
                            </div>

                            <div class="col-md-8">
                                <div class="card border-white">
                                    <div class="card-body border-white">
                                        <div class="dropdown d-flex d-xl-flex justify-content-end justify-content-xl-end">


                                            <button class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown" aria-expanded="false" type="button" style="font-size: 12px;">
                                                <i class="fa fa-gear"></i>
                                            </button>

                                            <div class="dropdown-menu" role="menu">

                                            <a class="dropdown-item btn btn-info btn-sm" role="presentation" href="/posts/<?php echo e($post->id); ?>/edit"><button class="btn btn-info btn-sm">Edit</button></a>

                                                <a class="dropdown-item" role="presentation" href="#">
                                                    
                                                    <?php echo Form::open(['action' => ['PostsController@destroy',$post->id], 'method' => 'POST' ]); ?>


                                                    <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                                                    <?php echo e(Form::submit('Remove',['class' => 'btn btn-danger btn-sm'])); ?>

                
                                                    <?php echo Form::close(); ?>

                                                </a>
                                              
                                            </div>
                                        </div>

                                        <p class="card-text">
                                            <?php echo e($post->created_at->diffForHumans()); ?>

                                        </p>

                                        <h5 class="d-xl-flex justify-content-xl-start card-title" style="color: rgb(98,98,98);padding: 0px;font-size: 22px;">
                                            <?php echo e($post->subject); ?>

                                        </h5> 

                                        <h6 class="text-muted card-subtitle mb-2"><?php echo e($post->fullName); ?></h6>

                                        <p class="card-text">
                                            <?php echo e($post->description); ?>

                                        </p>
                                        <a href="/posts/<?php echo e($post->id); ?>"><button class="btn btn-primary btn-sm" type="button">View</button></a>
                                    
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?> 
                
                <div class="col-md-12" data-aos="slide-up" style="margin: 10px 0 px;">
                <center>
                <h3>There are no Posts</h3>
                <img width="300px" src="/storage/assets/img/wait.png" />
                </center>
                </div>
                <?php endif; ?>

                <!--****************************************************
                            End of User Posts
                ******************************************************-->

            </div>
        </section>
    </div>
    <div class="col"></div>
</div>
</div>
</div>
</div>
</div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sltutorLaravel\resources\views/home.blade.php ENDPATH**/ ?>